<template>
  <div class="sowaka-page">
    <!-- Navigation -->
    <nav>
      <div class="logo">そわか</div>
      <ul class="nav-links" :class="{ 'mobile-open': mobileMenuOpen }">
        <li><a href="#story" @click="scrollToSection">物語</a></li>
        <li><a href="#concept" @click="scrollToSection">コンセプト</a></li>
        <li><a href="#rooms" @click="scrollToSection">客室</a></li>
        <li><a href="#news" @click="scrollToSection">お知らせ</a></li>
        <li><a href="#access" @click="scrollToSection">アクセス</a></li>
      </ul>
      <div class="menu-toggle" @click="toggleMobileMenu">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
      <div class="hero-content">
        <h1 class="hero-title">そわか</h1>
        <p class="hero-subtitle">SOWAKA KYOTO</p>
      </div>
    </section>

    <!-- Component 1: Vertical Logo and Text Section -->
    <section class="vertical-section fade-in" id="story" ref="storySection">
      <div class="vertical-container">
        <div class="vertical-logo-box">
          <div class="vertical-logo-text">SOWAKA</div>
        </div>
        <div class="vertical-text-container">
          <div class="vertical-column">誕生しました。</div>
          <div class="vertical-column">京都・祇園八坂に</div>
          <div class="vertical-column">ホテルが、</div>
          <div class="vertical-column">本物の質を味わう</div>
          <div class="vertical-column">そして新しい。</div>
          <div class="vertical-column">懐かしく、</div>
        </div>
      </div>
    </section>

    <!-- Unified Content Section -->
    <section class="unified-content-section fade-in">
      <div class="unified-content-container">
        <!-- First Part - Introduction Text -->
        <div class="content-block text-center-block">
          <p>「そわか」とは、サンスクリット語で「幸あれ」の意味。</p>
          <p>仏教の経典の最後にもしばしば用いられるこの祝福の言葉は</p>
          <p>耳に馴染みをして、そして新しく、仏教発祥の美しい響きとして皆様に届きます。</p>
          <p>エントランスをくぐり、打ち水のされた石畳を歩めばそこは、静けさに包まれた別世界。</p>
          <p>坪庭の緑に目を潤し、そよぐ風を感じながらお部屋で寛ぐ。</p>
        </div>

        <!-- Second Part - Main Story with Image -->
        <div class="content-block story-with-image-block">
          <div class="story-header-large">
            <h2>{{ storySection.header_title }}</h2>
            <p class="subtitle">{{ storySection.subtitle }}</p>
          </div>
          
          <div class="story-layout">
            <div class="story-image-left" v-if="storySection.image_url">
              <img :src="storySection.image_url" :alt="storySection.header_title" />
            </div>
            
            <div class="story-text-right">
              <p v-for="(paragraph, index) in storySection.paragraphs" :key="index">
                {{ paragraph }}
              </p>
              <p class="author-signature">{{ storySection.author_signature }}</p>
            </div>
          </div>
        </div>

        <!-- Third Part - Closing Message -->
        <div class="content-block text-center-block-final">
          <p>恵まれたロケーションもさることながら、このホテルの最大の魅力は、</p>
          <p>古き良きものと新しきものが融合した贅沢な空間にあります。</p>
          <p>日本の旬を贅沢に堪能するレストラン祇園 ろかせ、自由で美しき和食の世界を味わう。</p>
          <p>皆さま人のように、フットワーク軽く街を歩く。</p>
          <p>訪れる方々に幸いあれ、祝福あれ。</p>
          <p>数多なる幸せを、「そわか」でこころゆくまでお楽しみください。</p>
        </div>
      </div>
    </section>

    <!-- Characters/Rooms Section -->
    <section class="characters-section fade-in" id="rooms" ref="roomsSection">
      <div class="characters-grid">
        <div 
          v-for="(room, index) in rooms" 
          :key="room.id"
          class="character-card" 
          :class="{ active: activeRoom === room.id }"
          :data-room="room.id"
          @click="selectRoom(room.id, index)"
        >
          <div class="character-name">{{ room.name }}</div>
        </div>
      </div>
    </section>

    <!-- News Section -->
    <section class="news fade-in" id="news" ref="newsSection">
      <div 
        class="news-content" 
        :class="newsContentAlignment"
      >
        <transition name="fade" mode="out-in">
          <div 
            :key="activeRoomData.id"
            class="news-item room-content"
          >
            <div class="news-date">{{ activeRoomData.date }}</div>
            <div class="news-title">{{ activeRoomData.title }}</div>
            <div class="news-divider"></div>
            <div class="news-description">
              <p v-for="(paragraph, idx) in activeRoomData.description" :key="idx">
                {{ paragraph }}
              </p>
              <div v-if="activeRoomData.details" class="news-details">
                <p v-for="(detail, idx) in activeRoomData.details" :key="idx">
                  {{ detail }}
                </p>
              </div>
            </div>
          </div>
        </transition>
      </div>
    </section>

    <!-- Concept Section -->
    <section class="concept-section fade-in" id="concept" ref="conceptSection">
      <h2 class="section-title">― そわかの心 ―</h2>
      <div class="concept-grid">
        <div 
          v-for="concept in concepts" 
          :key="concept.id"
          class="concept-card"
        >
          <h3>{{ concept.title }}</h3>
          <p>{{ concept.description }}</p>
        </div>
      </div>
    </section>

    <!-- Footer -->
    <footer>
      <div class="footer-content">
        <div class="footer-logo">そわか</div>
        <ul class="footer-links">
          <li><a href="#story" @click="scrollToSection">物語</a></li>
          <li><a href="#concept" @click="scrollToSection">コンセプト</a></li>
          <li><a href="#rooms" @click="scrollToSection">客室</a></li>
          <li><a href="#dining">お食事</a></li>
          <li><a href="#spa">スパ</a></li>
          <li><a href="#wedding">ウェディング</a></li>
          <li><a href="#access">交通案内</a></li>
          <li><a href="#contact">お問い合わせ</a></li>
        </ul>
        <div class="footer-info">
          〒605-0000 京都府京都市東山区下河原通八坂鳥居前下る<br>
          TEL: 075-541-5323<br>
          E-mail: info@sowaka.com<br>
          営業時間: 24時間 (チェックイン 15:00 / チェックアウト 12:00)
        </div>
        <div class="copyright">
          © 2025 SOWAKA KYOTO. All Rights Reserved.
        </div>
      </div>
    </footer>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import axios from 'axios'
import { storySectionApi } from '../api/mongoApi'

// API基础URL
const API_BASE_URL = 'http://localhost:3000/api'

// 移动端菜单状态
const mobileMenuOpen = ref(false)

// 当前选中的房间
const activeRoom = ref('garden')

// 当前房间索引
const activeRoomIndex = ref(0)

// 加载状态
const loading = ref(true)
const error = ref(null)

// 房间数据（从数据库加载）
const rooms = ref([])

// 概念卡片数据（从数据库加载）
const concepts = ref([])

// 故事内容（从数据库加载）
const storyContent = ref({
  title: '',
  html_content: ''
})

// 故事章节数据（从数据库加载）
const storySection = ref({
  header_title: 'そわかの物語',
  subtitle: 'STORY OF SOWAKA',
  paragraphs: [],
  author_signature: '— SOWAKA KYOTO',
  image_url: ''
})

// 从数据库加载内容
async function loadContents() {
  try {
    loading.value = true
    error.value = null
    
    // 加载房间数据
    const roomsResponse = await axios.get(`${API_BASE_URL}/contents/type/room`)
    if (roomsResponse.data.success) {
      rooms.value = roomsResponse.data.data.map((room, index) => {
        // 解析HTML内容提取信息
        const parser = new DOMParser()
        const doc = parser.parseFromString(room.html_content, 'text/html')
        
        // 提取标题和描述
        const h2 = doc.querySelector('h2')
        const paragraphs = doc.querySelectorAll('p')
        const listItems = doc.querySelectorAll('li')
        
        return {
          id: room.id,
          name: room.title,
          date: room.created_at ? new Date(room.created_at).toLocaleDateString('ja-JP') : '',
          title: h2 ? h2.textContent : room.title,
          description: Array.from(paragraphs).slice(0, 3).map(p => p.textContent),
          details: Array.from(listItems).map(li => li.textContent),
          html_content: room.html_content
        }
      })
      
      // 设置默认选中第一个房间
      if (rooms.value.length > 0) {
        activeRoom.value = rooms.value[0].id
      }
    }
    
    // 加载概念数据
    const conceptsResponse = await axios.get(`${API_BASE_URL}/contents/type/concept`)
    if (conceptsResponse.data.success) {
      concepts.value = conceptsResponse.data.data.map(concept => {
        // 解析HTML内容
        const parser = new DOMParser()
        const doc = parser.parseFromString(concept.html_content, 'text/html')
        const paragraphs = doc.querySelectorAll('p')
        
        return {
          id: concept.id,
          title: concept.title,
          description: paragraphs.length > 0 ? paragraphs[paragraphs.length - 1].textContent : ''
        }
      })
    }
    
    // 加载故事内容
    const storyResponse = await axios.get(`${API_BASE_URL}/contents/type/story`)
    if (storyResponse.data.success && storyResponse.data.data.length > 0) {
      const story = storyResponse.data.data[0]
      storyContent.value = {
        title: story.title,
        html_content: story.html_content
      }
    }
    
    // 加载故事章节数据（从MongoDB）
    const storySectionResponse = await storySectionApi.getActiveStorySections()
    if (storySectionResponse.data.success && storySectionResponse.data.data.length > 0) {
      const section = storySectionResponse.data.data[0]
      storySection.value = {
        header_title: section.headerTitle,
        subtitle: section.subtitle,
        paragraphs: section.paragraphs || [],
        author_signature: section.authorSignature,
        image_url: section.imageUrl
      }
    }
    
  } catch (err) {
    console.error('加载内容失败:', err)
    error.value = '加载内容失败，请确保后端服务器正在运行'
    
    // 使用默认数据作为后备
    loadDefaultData()
  } finally {
    loading.value = false
  }
}

// 加载默认数据（后备方案）
function loadDefaultData() {
  rooms.value = [
    {
      id: 'garden',
      name: '庭園の間',
      date: '2025.02.13',
      title: 'スモールラグジュアリーホテル「SOWAKA（そわか）」',
      description: [
        '歴史的建築を改修した唯一性や、グローバルスタンダードと日本的な品格さを融合したホスピタリティの形を評価いただいた背景、大変光栄に思っております。'
      ]
    }
  ]
  
  concepts.value = [
    {
      id: 'tradition',
      title: '伝統と革新',
      description: '京都祇園八坂に佇む、歴史ある建築と現代的な快適さが調和した空間。古き良き日本の美意識を守りながら、新しい価値を創造します。'
    }
  ]
}

// 新闻内容对齐方式
const newsContentAlignment = computed(() => {
  const alignments = ['align-left', 'align-center', 'align-right']
  return alignments[activeRoomIndex.value] || 'align-left'
})

// 获取当前激活的房间数据
const activeRoomData = computed(() => {
  return rooms.value.find(room => room.id === activeRoom.value) || rooms.value[0] || {
    id: 'default',
    name: '読み込み中...',
    date: '',
    title: '',
    description: [],
    details: []
  }
})

// 切换移动端菜单
const toggleMobileMenu = () => {
  mobileMenuOpen.value = !mobileMenuOpen.value
}

// 选择房间
const selectRoom = (roomId, index) => {
  activeRoom.value = roomId
  activeRoomIndex.value = index
}

// 滚动到指定区域
const scrollToSection = (event) => {
  event.preventDefault()
  const href = event.target.getAttribute('href')
  if (href && href.startsWith('#')) {
    const target = document.querySelector(href)
    if (target) {
      target.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      })
      // 关闭移动端菜单
      mobileMenuOpen.value = false
    }
  }
}

// 页面挂载时加载数据和设置动画
onMounted(async () => {
  // 加载数据库内容
  await loadContents()
  
  // 滚动动画观察器
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -80px 0px'
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible')
      }
    })
  }, observerOptions)

  document.querySelectorAll('.fade-in').forEach(el => {
    observer.observe(el)
  })
})
</script>

<style scoped>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

.sowaka-page {
  font-family: 'Yu Mincho', 'YuMincho', 'Hiragino Mincho Pro', 'MS PMincho', serif;
  color: #333;
  background-color: #faf9f7;
  line-height: 1.8;
  overflow-x: hidden;
}

/* Navigation */
nav {
  position: fixed;
  top: 0;
  width: 100%;
  background-color: rgba(250, 249, 247, 0.95);
  backdrop-filter: blur(10px);
  z-index: 1000;
  padding: 20px 50px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid rgba(51, 51, 51, 0.1);
}

.logo {
  font-size: 24px;
  font-weight: 300;
  letter-spacing: 3px;
  color: #333;
}

.nav-links {
  display: flex;
  gap: 40px;
  list-style: none;
}

.nav-links a {
  text-decoration: none;
  color: #333;
  font-size: 14px;
  letter-spacing: 2px;
  transition: opacity 0.3s;
  font-weight: 300;
}

.nav-links a:hover {
  opacity: 0.6;
}

.menu-toggle {
  display: none;
  flex-direction: column;
  cursor: pointer;
  gap: 5px;
}

.menu-toggle span {
  width: 25px;
  height: 2px;
  background-color: #333;
}

/* Hero Section */
.hero {
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(to bottom, #faf9f7 0%, #f5f0eb 100%);
}

.hero-content {
  text-align: center;
  padding: 0 20px;
}

.hero-title {
  font-size: 52px;
  font-weight: 300;
  letter-spacing: 12px;
  margin-bottom: 30px;
  color: #333;
  opacity: 0;
  animation: fadeInUp 1s forwards 0.3s;
}

.hero-subtitle {
  font-size: 16px;
  letter-spacing: 3px;
  color: #666;
  font-weight: 300;
  opacity: 0;
  animation: fadeInUp 1s forwards 0.6s;
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Component 1: Vertical Logo and Text */
.vertical-section {
  padding: 120px 50px;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #faf9f7;
  min-height: 80vh;
}

.vertical-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 50px;
}

.vertical-logo-box {
  background-color: #1a1a1a;
  padding: 25px 15px;
  display: flex;
  justify-content: center;
  align-items: center;
}

.vertical-logo-text {
  writing-mode: vertical-rl;
  text-orientation: upright;
  font-size: 22px;
  letter-spacing: 0.4em;
  color: #fff;
  font-weight: 300;
}

.vertical-text-container {
  display: flex;
  gap: 25px;
  padding: 40px 50px;
  border-left: 1px solid #ccc;
  border-right: 1px solid #ccc;
}

.vertical-column {
  writing-mode: vertical-rl;
  font-size: 15px;
  letter-spacing: 0.15em;
  color: #555;
  line-height: 2;
}

/* Unified Content Section */
.unified-content-section {
  background-color: #faf9f7;
}

.unified-content-container {
  max-width: 1400px;
  margin: 0 auto;
}

.content-block {
  padding: 100px 50px;
}

/* Text Center Blocks */
.text-center-block,
.text-center-block-final {
  text-align: center;
  max-width: 900px;
  margin: 0 auto;
}

.text-center-block p,
.text-center-block-final p {
  font-size: 15px;
  line-height: 3;
  color: #555;
  margin-bottom: 10px;
  letter-spacing: 0.08em;
}

.text-center-block {
  background-color: #faf9f7;
}

.text-center-block-final {
  background-color: #faf9f7;
  padding-bottom: 120px;
}

/* Story with Image Block */
.story-with-image-block {
  background-color: #faf9f7 !important;
  padding: 120px 50px !important;
}

.story-header-large {
  text-align: center;
  margin-bottom: 100px;
}

.story-header-large h2 {
  font-size: 42px;
  font-weight: 300;
  letter-spacing: 8px;
  color: #555;
  margin-bottom: 20px;
}

.story-header-large .subtitle {
  font-size: 13px;
  letter-spacing: 3px;
  color: #999;
  text-transform: uppercase;
}

.story-layout {
  display: grid;
  grid-template-columns: 45% 55%;
  gap: 0;
  max-width: 1300px;
  margin: 0 auto;
}

.story-image-left {
  background: linear-gradient(135deg, #d4c5b0 0%, #c4b5a0 100%);
  min-height: 600px;
  position: relative;
  overflow: hidden;
}

.story-image-left img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  position: absolute;
  top: 0;
  left: 0;
}

.story-image-left::after {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(to bottom, transparent 70%, rgba(0,0,0,0.05) 100%);
  z-index: 1;
}

.story-text-right {
  background-color: #fff;
  padding: 80px 70px;
  border-left: 3px solid #c9a96e;
}

.story-text-right p {
  font-size: 14px;
  line-height: 2.5;
  color: #666;
  margin-bottom: 25px;
  letter-spacing: 0.05em;
}

.story-text-right .author-signature {
  font-size: 12px;
  color: #999;
  text-align: right;
  margin-top: 50px;
  font-style: italic;
}

/* Character Cards Section */
.characters-section {
  padding: 0;
  background-color: #3d4a3d;
  position: relative;
  padding-bottom: 450px;
}

.characters-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 2px;
  width: 100%;
  background-color: #2a3a2a;
}

.character-card {
  aspect-ratio: 4/3;
  background: linear-gradient(135deg, #5a6b5a 0%, #4a5a4a 100%);
  position: relative;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.4s ease;
  display: flex;
  align-items: flex-end;
  padding: 40px;
}

.character-card.active {
  transform: translateY(-5px);
  z-index: 10;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.6);
  background: linear-gradient(135deg, #6a7b6a 0%, #5a6a5a 100%);
}

.character-card:not(.active) {
  opacity: 0.6;
}

.character-card:hover:not(.active) {
  opacity: 0.8;
}

.character-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(to top, rgba(0,0,0,0.5) 0%, transparent 70%);
  z-index: 1;
  transition: all 0.4s;
}

.character-card.active::before {
  background: linear-gradient(to top, rgba(0,0,0,0.6) 0%, transparent 60%);
}

.character-name {
  position: relative;
  color: #f0f0f0;
  font-size: 22px;
  font-weight: 300;
  letter-spacing: 3px;
  z-index: 2;
  text-shadow: 0 2px 8px rgba(0,0,0,0.4);
  transition: all 0.3s;
}

.character-card.active .character-name {
  font-size: 24px;
  letter-spacing: 4px;
  color: #fff;
}

/* News Section */
.news {
  padding: 0;
  margin: 0;
  background-color: transparent;
  display: block;
  position: relative;
  z-index: 1;
}

.news-content {
  background-color: rgba(70, 70, 70, 0.98);
  backdrop-filter: blur(10px);
  flex: 0 0 auto;
  padding: 50px 45px;
  max-width: 520px;
  min-width: 380px;
  position: absolute;
  bottom: 60px;
  z-index: 100;
  left: 0;
  transition: left 0.6s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
  border-left: 3px solid rgba(255, 255, 255, 0.1);
}

.news-content.align-left {
  left: 3%;
}

.news-content.align-center {
  left: 36%;
}

.news-content.align-right {
  left: 69%;
}

.news-item {
  transition: all 0.3s;
  cursor: default;
}

.news-date {
  font-size: 13px;
  color: #e8e8e8;
  letter-spacing: 2px;
  margin-bottom: 20px;
  font-weight: 300;
  text-transform: uppercase;
}

.news-title {
  font-size: 18px;
  color: #ffffff;
  line-height: 2;
  letter-spacing: 0.1em;
  margin-bottom: 20px;
  font-weight: 400;
}

.news-description {
  font-size: 13px;
  color: #d4d4d4;
  line-height: 2.2;
  letter-spacing: 0.05em;
}

.news-description p {
  margin-bottom: 15px;
}

.news-divider {
  width: 60px;
  height: 1px;
  background-color: #999;
  margin: 30px 0;
}

.news-details {
  margin-top: 25px;
  padding-top: 0;
  border-left: none;
}

.news-details p {
  font-size: 13px;
  color: #bbb;
  line-height: 1.8;
  margin-bottom: 8px;
}

/* Concept Section */
.concept-section {
  padding: 150px 50px;
  background-color: #faf9f7;
  margin-top: 0;
  position: relative;
  z-index: 0;
}

.section-title {
  text-align: center;
  font-size: 14px;
  letter-spacing: 5px;
  margin-bottom: 80px;
  color: #555;
  font-weight: 300;
  padding: 25px 0;
  border-top: 1px solid #ccc;
  border-bottom: 1px solid #ccc;
  display: block;
  width: 100%;
  max-width: 600px;
  margin-left: auto;
  margin-right: auto;
}

.concept-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 50px;
  max-width: 1400px;
  margin: 0 auto;
}

.concept-card {
  background-color: #fff;
  padding: 60px 50px;
  border: none;
  text-align: center;
  transition: transform 0.3s, box-shadow 0.3s;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}

.concept-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
}

.concept-card h3 {
  font-size: 18px;
  font-weight: 400;
  letter-spacing: 3px;
  margin-bottom: 30px;
  color: #333;
  padding-bottom: 20px;
  border-bottom: 1px solid #e8e0d5;
}

.concept-card p {
  font-size: 14px;
  line-height: 2.5;
  color: #666;
  letter-spacing: 0.05em;
  text-align: left;
}

/* Footer */
footer {
  background-color: #2a2a2a;
  color: #aaa;
  padding: 80px 50px 40px;
  text-align: center;
}

.footer-logo {
  font-size: 28px;
  letter-spacing: 6px;
  margin-bottom: 40px;
  color: #d4c5b0;
  font-weight: 300;
}

.footer-links {
  display: flex;
  justify-content: center;
  gap: 40px;
  margin-bottom: 50px;
  list-style: none;
  flex-wrap: wrap;
}

.footer-links a {
  color: #aaa;
  text-decoration: none;
  font-size: 13px;
  letter-spacing: 2px;
  transition: color 0.3s;
}

.footer-links a:hover {
  color: #d4c5b0;
}

.footer-info {
  font-size: 13px;
  line-height: 2.2;
  color: #888;
  margin-bottom: 40px;
}

.copyright {
  font-size: 11px;
  color: #666;
  letter-spacing: 1px;
  padding-top: 30px;
  border-top: 1px solid #444;
}

/* Scroll Animations */
.fade-in {
  opacity: 0;
  transform: translateY(40px);
  transition: opacity 0.8s, transform 0.8s;
}

.fade-in.visible {
  opacity: 1;
  transform: translateY(0);
}

/* Fade transition for room content */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

/* Responsive */
@media (max-width: 768px) {
  nav {
    padding: 15px 20px;
  }

  .nav-links {
    display: none;
  }

  .nav-links.mobile-open {
    display: flex;
    flex-direction: column;
    position: absolute;
    top: 70px;
    right: 20px;
    background: rgba(250, 249, 247, 0.98);
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    gap: 20px;
  }

  .menu-toggle {
    display: flex;
  }

  .hero-title {
    font-size: 36px;
    letter-spacing: 8px;
  }

  .vertical-section {
    padding: 80px 20px;
  }

  .vertical-text-container {
    gap: 20px;
    padding: 0 20px;
  }

  .vertical-column {
    font-size: 14px;
  }

  .unified-content-section .content-block {
    padding: 60px 20px;
  }

  .story-header-large h2 {
    font-size: 32px;
    letter-spacing: 4px;
  }

  .story-layout {
    grid-template-columns: 1fr;
    gap: 0;
  }

  .story-text-right {
    padding: 40px 30px;
  }

  .concept-section {
    padding: 80px 20px;
  }

  .concept-grid {
    grid-template-columns: 1fr;
    gap: 30px;
  }

  .characters-section {
    min-height: auto;
    padding: 20px 0;
    padding-bottom: 100px;
  }

  .characters-grid {
    grid-template-columns: 1fr;
    gap: 1px;
  }

  .character-card {
    aspect-ratio: 16/9;
  }

  .news {
    position: relative;
    margin-top: 0;
  }

  .news-content {
    padding: 35px 25px;
    min-width: auto;
    max-width: calc(100% - 40px);
    position: relative;
    left: 0 !important;
    bottom: auto;
    margin: 20px;
    border-left: 2px solid rgba(255, 255, 255, 0.1);
  }

  .footer-links {
    flex-direction: column;
    gap: 20px;
  }
}
</style>


