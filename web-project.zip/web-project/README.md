# SILENT HAZE - Vue 3 集成项目

这是一个将原生HTML页面成功集成到Vue 3框架的艺术展示项目。

## ✨ 项目特色

- 🎨 **多页面设计**: 首页（樱花主题）+ 蓝色页面（夏日/雨天主题）+ Sowaka 页面（京都酒店主题）
- 🎭 **丰富特效**: Canvas动画、粒子系统、Perlin噪声、视差滚动
- 🚀 **现代技术栈**: Vue 3 + Vue Router + Vite
- 📱 **响应式设计**: 完美支持桌面和移动设备
- ⚡ **性能优化**: 硬件加速、requestAnimationFrame、资源懒加载

## 🚀 快速开始

### 1. 安装依赖

```bash
npm install
```

### 2. 复制媒体资源

**重要！** 运行批处理文件自动复制资源：

```bash
# Windows
COPY_ASSETS.bat

# 或手动复制（参见 SETUP.md）
```

### 3. 启动开发服务器

```bash
npm run dev
```

访问 http://localhost:5173

### 4. 构建生产版本

```bash
npm run build
npm run preview
```

## 📁 项目结构

```
web-project/
├── public/              # 静态资源（图片、视频）
├── src/
│   ├── composables/     # 组合式函数（特效逻辑）
│   ├── router/          # 路由配置
│   ├── utils/           # 工具函数
│   ├── views/           # 页面组件
│   │   ├── HomePage.vue     # 首页
│   │   ├── BluePage.vue     # 蓝色页面
│   │   └── SowakaPage.vue   # Sowaka 酒店页面
│   ├── App.vue          # 根组件
│   └── main.js          # 入口文件
├── SETUP.md             # 详细设置指南
├── Sowaka页面移植说明.md # Sowaka 页面文档
└── COPY_ASSETS.bat      # 资源复制脚本
```

## 🎯 功能特性

### 首页 (/)
- ✅ 樱花飘落动画
- ✅ 丝带Canvas动画
- ✅ 波纹点击效果
- ✅ 背景视频播放
- ✅ 日文排版设计
- ✅ 路由导航

### 蓝色页面 (/blue)
- ✅ Perlin噪声文字效果
- ✅ 雨滴粒子系统
- ✅ 双侧模糊背景动画
- ✅ 视差滚动效果
- ✅ 图片/视频切换
- ✅ 返回导航

### Sowaka 页面 (/sowaka)
- ✅ 响应式导航栏（支持移动端）
- ✅ Hero 区域动画
- ✅ 垂直日文排版展示
- ✅ 客室卡片交互
- ✅ 动态内容切换
- ✅ 平滑滚动导航
- ✅ 概念展示卡片
- ✅ 完整的响应式设计

## 🛠️ 技术栈

- **Vue 3.5** - Composition API
- **Vue Router 4.5** - 单页面路由
- **Vite 7** - 极速构建工具
- **Canvas API** - 2D图形渲染
- **CSS3 Animations** - 流畅动画效果

## 📖 详细文档

- [SETUP.md](./SETUP.md) - 完整设置指南
- [Sowaka页面移植说明.md](./Sowaka页面移植说明.md) - Sowaka 页面详细文档
- [package.json](./package.json) - 依赖配置
- [vite.config.js](./vite.config.js) - Vite配置

## 🎨 特效模块

所有特效已模块化，可在其他项目中复用：

| 模块 | 功能 | 文件 |
|------|------|------|
| Perlin Noise | 噪声生成器 | `utils/perlinNoise.js` |
| Cherry Blossoms | 樱花飘落 | `utils/cherryBlossoms.js` |
| Ribbon Animation | 丝带动画 | `utils/ribbonAnimation.js` |
| Ripple Effect | 波纹效果 | `utils/rippleEffect.js` |
| Blue Page Effects | 综合特效 | `composables/useBluePageEffects.js` |

## 🔧 开发建议

### 添加新页面
1. 在 `src/views/` 创建 `.vue` 文件
2. 在 `src/router/index.js` 添加路由
3. 使用 `<router-link>` 创建链接

### 性能优化
- 使用 `requestAnimationFrame` 进行动画
- Canvas使用 `desynchronized` 选项
- 组件卸载时清理资源
- 图片/视频懒加载

## 🐛 常见问题

**Q: 媒体文件无法加载？**  
A: 运行 `COPY_ASSETS.bat` 或手动复制文件到 `public/` 目录

**Q: npm命令不可用？**  
A: 确保已安装 Node.js (v20.19.0+ 或 v22.12.0+)

**Q: 页面白屏？**  
A: 检查浏览器控制台错误，确保运行了 `npm install`

## 📝 IDE推荐

- [VS Code](https://code.visualstudio.com/)
- [Vue (Official)](https://marketplace.visualstudio.com/items?itemName=Vue.volar)
- [Vue.js devtools](https://chromewebstore.google.com/detail/vuejs-devtools/nhdogjmejiglipccpnnnanhbledajbpd)

## 📄 许可证

根据项目需求设置

---

**从原生HTML到Vue 3的完美迁移 ✨**
